# R_in_ecology
materials showing some ways that I use R in ecology

work in progress
